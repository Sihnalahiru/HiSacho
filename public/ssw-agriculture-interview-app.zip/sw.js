/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "402b66900e731ca748771b6fc5e7a068"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "5a9aa1ebac81ab526cd261796f895e69"
  }, {
    "url": "pwa-512x512.png",
    "revision": "f7a0b77c7869a696489f5d7693766171"
  }, {
    "url": "pwa-192x192.png",
    "revision": "f8871be0e3222a2c2fd3aa78ff69c9e1"
  }, {
    "url": "index.html",
    "revision": "321601960ec1d174a3187332457ca30f"
  }, {
    "url": "icon.svg",
    "revision": "d5620bb3b8b01772ef2eb76a8f98ec54"
  }, {
    "url": "favicon.ico",
    "revision": "0745cfc035ecdca142111553cd789dc4"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "01899bd6ac4f38f2feb0311c3deb8f52"
  }, {
    "url": "404.html",
    "revision": "96cbb677ca10d5e7dc96fb6e9142383a"
  }, {
    "url": "assets/index-CNEm9UGs.js",
    "revision": null
  }, {
    "url": "assets/index-BBzpWd7m.css",
    "revision": null
  }, {
    "url": "assets/aistudio/IMG_1692_e86f2112.png",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "01899bd6ac4f38f2feb0311c3deb8f52"
  }, {
    "url": "favicon.ico",
    "revision": "0745cfc035ecdca142111553cd789dc4"
  }, {
    "url": "icon.svg",
    "revision": "d5620bb3b8b01772ef2eb76a8f98ec54"
  }, {
    "url": "pwa-192x192.png",
    "revision": "f8871be0e3222a2c2fd3aa78ff69c9e1"
  }, {
    "url": "pwa-512x512.png",
    "revision": "f7a0b77c7869a696489f5d7693766171"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "5a9aa1ebac81ab526cd261796f895e69"
  }, {
    "url": "manifest.webmanifest",
    "revision": "96146153ac996e0852ce2e12ed295fd6"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
